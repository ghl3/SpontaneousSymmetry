

from RocksPaper import RPS

Game = RPS()

Game.playNext()
Game.playNext()
Game.playNext()
Game.playNext()
Game.playNext()
Game.playNext()
Game.playNext()
Game.playNext()
Game.playNext()
Game.playNext()
Game.playNext()
